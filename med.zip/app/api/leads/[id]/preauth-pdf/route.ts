import { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getSessionFromRequest } from '@/lib/session'
import { errorResponse, unauthorizedResponse } from '@/lib/api-utils'

function isImageUrl(url: string): boolean {
  const u = url.toLowerCase().split('?')[0]
  return (
    u.endsWith('.png') ||
    u.endsWith('.jpg') ||
    u.endsWith('.jpeg') ||
    u.endsWith('.gif') ||
    u.endsWith('.webp')
  )
}

function isPdfUrl(url: string): boolean {
  const u = url.toLowerCase().split('?')[0]
  return u.endsWith('.pdf')
}

async function fetchUrlAsBase64(url: string): Promise<{ data: string; mime: string } | null> {
  try {
    const res = await fetch(url, { cache: 'no-store' })
    if (!res.ok) return null
    const buf = Buffer.from(await res.arrayBuffer())
    const base64 = buf.toString('base64')
    const contentType = res.headers.get('content-type') || 'application/octet-stream'
    const mime = contentType.split(';')[0].trim().toLowerCase()
    return { data: base64, mime }
  } catch {
    return null
  }
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
}

/** Numeric zero (and common formatted variants) — omit from PDF; empty/null is not treated as zero. */
function isZeroLike(s: string | null | undefined): boolean {
  if (s == null) return false
  const t = String(s).trim()
  if (t === '') return false
  const normalized = t.replace(/[₹,\s%]/g, '')
  if (normalized === '') return false
  if (/^-?0+\.?0*$/.test(normalized)) return true
  const n = Number(normalized)
  return !Number.isNaN(n) && n === 0
}

function nzString(n: number | null | undefined): string | null {
  if (n == null || n === 0) return null
  return String(n)
}

type FileEntry = { name?: string; url?: string }

function pushJsonFileUrls(arr: unknown, out: string[]) {
  if (!Array.isArray(arr)) return
  for (const item of arr) {
    const u = item && typeof item === 'object' && 'url' in item ? (item as FileEntry).url : null
    if (typeof u === 'string' && u.trim()) out.push(u.trim())
  }
}

function classifyFetched(url: string, mime: string): 'pdf' | 'image' | 'skip' {
  const m = mime.split(';')[0].trim().toLowerCase()
  if (m === 'application/pdf' || m.includes('pdf')) return 'pdf'
  if (m.startsWith('image/')) return 'image'
  if (isPdfUrl(url)) return 'pdf'
  if (isImageUrl(url)) return 'image'
  return 'skip'
}

type SuggestedHospital = {
  hospitalName: string
  requestedRoomType?: string | null
  roomRentSingle?: number | null
  roomRentSemiPrivate?: number | null
  roomRentDeluxe?: number | null
  roomRentGeneral?: number | null
}

function getSelectedHospitalRoomRent(
  suggestedHospitals: SuggestedHospital[] | null | undefined,
  requestedHospitalName: string | null | undefined,
  requestedRoomType: string | null | undefined
): string | null {
  if (!requestedHospitalName?.trim() || !suggestedHospitals?.length) return null
  const selected = suggestedHospitals.find(
    (h) => h.hospitalName?.trim() === requestedHospitalName.trim()
  )
  if (!selected) return null
  const rt = (requestedRoomType || '').toLowerCase().replace(/\s+/g, ' ')
  if (rt.includes('single') && selected.roomRentSingle != null)
    return nzString(selected.roomRentSingle)
  if ((rt.includes('semi') || rt.includes('private')) && selected.roomRentSemiPrivate != null)
    return nzString(selected.roomRentSemiPrivate)
  if (rt.includes('deluxe') && selected.roomRentDeluxe != null) return nzString(selected.roomRentDeluxe)
  if (rt.includes('general') && selected.roomRentGeneral != null) return nzString(selected.roomRentGeneral)
  return selected.roomRentSingle != null
    ? nzString(selected.roomRentSingle)
    : selected.roomRentSemiPrivate != null
      ? nzString(selected.roomRentSemiPrivate)
      : selected.roomRentDeluxe != null
        ? nzString(selected.roomRentDeluxe)
        : selected.roomRentGeneral != null
          ? nzString(selected.roomRentGeneral)
          : null
}

function buildPreAuthHtml(params: {
  patientName: string
  initialApproval: string | null
  tentativeCost: string | null
  preAuth: {
    insurance: string | null
    tpa: string | null
    sumInsured: string | null
    roomRent: string | null
    capping: string | null
    copay: string | null
    icu: string | null
    requestedHospitalName: string | null
    requestedRoomType: string | null
    diseaseDescription: string | null
    doctorName: string | null
  }
  admissionDate: string | null
  surgeryDate: string | null
  imageDataUrls: Array<{ data: string; mime: string }>
  pdfBase64List: string[]
}): string {
  const { patientName, initialApproval, tentativeCost, preAuth, admissionDate, surgeryDate, imageDataUrls, pdfBase64List } = params

  /** hide = omit card; dash = show —; else show escaped text */
  function fieldCell(raw: string | null | undefined): 'hide' | 'dash' | string {
    if (raw == null) return 'dash'
    const t = String(raw).trim()
    if (t === '') return 'dash'
    if (isZeroLike(t)) return 'hide'
    return escapeHtml(t)
  }

  const diseaseRaw = preAuth.diseaseDescription != null ? String(preAuth.diseaseDescription).trim() : ''
  const diseaseCell =
    diseaseRaw === ''
      ? ('dash' as const)
      : isZeroLike(diseaseRaw)
        ? ('hide' as const)
        : ('text' as const)

  const patientCell = fieldCell(patientName)
  const patientHeadingHtml =
    patientCell === 'hide'
      ? ''
      : `<h1 class="patient-name">${patientCell === 'dash' ? escapeHtml('—') : patientCell}</h1>`

  const initialApprovalCell = fieldCell(initialApproval)
  const tentativeCostCell = fieldCell(tentativeCost)
  const financialHeroHtml = `
    <div class="financial-hero">
      <div class="financial-label">Initial Approval</div>
      <div class="financial-initial">${initialApprovalCell === 'hide' || initialApprovalCell === 'dash' ? escapeHtml('—') : initialApprovalCell}</div>
      <div class="financial-divider">
        <div class="financial-label">Tentative Cost</div>
        <div class="financial-tentative">${tentativeCostCell === 'hide' || tentativeCostCell === 'dash' ? escapeHtml('—') : tentativeCostCell}</div>
      </div>
    </div>`

  const cardDefs: Array<{ label: string; cell: 'hide' | 'dash' | string; fullWidth?: boolean }> = [
    { label: 'Hospital', cell: fieldCell(preAuth.requestedHospitalName) },
    { label: 'Doctor', cell: fieldCell(preAuth.doctorName) },
    { label: 'Date of Admission', cell: fieldCell(admissionDate) },
    { label: 'Date of Surgery', cell: fieldCell(surgeryDate) },
    { label: 'Insurance', cell: fieldCell(preAuth.insurance) },
    { label: 'TPA', cell: fieldCell(preAuth.tpa) },
    { label: 'Sum Insured', cell: fieldCell(preAuth.sumInsured) },
    { label: 'Room Rent', cell: fieldCell(preAuth.roomRent) },
    { label: 'Capping', cell: fieldCell(preAuth.capping) },
    { label: 'Copay', cell: fieldCell(preAuth.copay) },
    { label: 'ICU', cell: fieldCell(preAuth.icu) },
    { label: 'Room Type', cell: fieldCell(preAuth.requestedRoomType) },
    {
      label: 'Disease Description',
      cell:
        diseaseCell === 'hide'
          ? 'hide'
          : diseaseCell === 'dash'
            ? 'dash'
            : escapeHtml(diseaseRaw.slice(0, 2000)),
      fullWidth: true,
    },
  ]

  const cardHtml = cardDefs
    .filter((c) => c.cell !== 'hide')
    .map(
      (c) =>
        `<div class="card${c.fullWidth ? ' card-full' : ''}"><div class="card-label">${escapeHtml(c.label)}</div><div class="card-value">${c.cell === 'dash' ? escapeHtml('—') : c.cell}</div></div>`
    )
    .join('')

  const imagePages = imageDataUrls
    .map(
      (img) =>
        `<div class="doc-page"><img src="data:${img.mime};base64,${img.data}" alt="Document" class="doc-image" /></div>`
    )
    .join('')

  // Raw JSON in script[type=application/json]: pdfs are base64 from our fetch (no </script> in alphabet)
  const pdfJson = JSON.stringify({
    pdfs: pdfBase64List,
    imageDocCount: imageDataUrls.length,
  })

  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Pre-Authorization Summary</title>
  <style>
    * { box-sizing: border-box; }
    body { font-family: system-ui, -apple-system, sans-serif; font-size: 14px; line-height: 1.45; color: #1a1a1a; margin: 0; padding: 0; }
    .header-strip { background: #2563eb; padding: 18px 24px; margin: 0 0 0 0; }
    .header-title { font-size: 26px; font-weight: 700; color: #fff; margin: 0; }
    .patient-name { font-size: 28px; font-weight: 700; margin: 24px 24px 20px 24px; color: #0f172a; line-height: 1.2; }
    .content { padding: 0 0 24px 0; }
    .preauth-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; padding: 0 24px; margin-bottom: 8px; }
    .financial-hero { margin: 0 24px 20px auto; padding: 14px 18px; border-radius: 12px; background: linear-gradient(135deg, #3b82f6, #1d4ed8); color: #fff; max-width: 200px; text-align: right; }
    .financial-label { font-size: 10px; font-weight: 700; letter-spacing: 0.14em; text-transform: uppercase; color: #bfdbfe; margin-bottom: 4px; }
    .financial-initial { font-size: 28px; font-weight: 800; line-height: 1.1; }
    .financial-tentative { font-size: 16px; font-weight: 600; line-height: 1.2; color: #dbeafe; margin-top: 2px; }
    .financial-divider { border-top: 1px solid rgba(191, 219, 254, 0.4); margin-top: 10px; padding-top: 10px; }
    .card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 14px 16px; background: #f8fafc; }
    .card-full { grid-column: 1 / -1; }
    .card-label { font-size: 12px; color: #64748b; margin-bottom: 6px; font-weight: 500; }
    .card-value { font-size: 15px; font-weight: 600; color: #0f172a; word-break: break-word; white-space: pre-wrap; }
    .doc-page { page-break-before: always; display: flex; align-items: flex-start; justify-content: center; padding: 0; margin: 0; min-height: 100vh; }
    .doc-image { max-width: 100%; max-height: 100vh; width: auto; height: auto; display: block; object-fit: contain; }
    .pdf-host { }
    .pdf-host .doc-page canvas { max-width: 100%; height: auto; display: block; margin: 0 auto; }
    .print-button-container { padding: 16px 24px; text-align: center; }
    .print-button { padding: 12px 24px; font-size: 16px; background: #2563eb; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: 600; }
    .print-button:hover:not(:disabled) { background: #1d4ed8; }
    .print-button:disabled { opacity: 0.65; cursor: not-allowed; }
    .pdf-status { padding: 8px 24px; text-align: center; font-size: 14px; color: #475569; }
    @media print {
      body { padding: 0; margin: 0; }
      .header-strip { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .doc-page { page-break-before: always; page-break-after: auto; page-break-inside: avoid; }
      .doc-image { max-height: 100vh; }
      .print-button-container, .pdf-status { display: none; }
    }
  </style>
</head>
<body>
  <div class="header-strip">
    <p class="header-title">Pre-Authorization Summary</p>
  </div>
  <div class="content">
    ${patientHeadingHtml}
    ${financialHeroHtml}
    <div class="preauth-grid">${cardHtml}</div>
  </div>
  ${imagePages}
  <div id="pdf-pages-root" class="pdf-host"></div>
  <p id="pdf-load-status" class="pdf-status" ${pdfBase64List.length === 0 ? 'style="display:none"' : ''}>Loading PDF documents…</p>
  <div class="print-button-container">
    <button type="button" class="print-button" id="print-btn" ${pdfBase64List.length > 0 ? 'disabled' : ''} onclick="window.print()">Print / Save as PDF</button>
  </div>
  <script id="preauth-pdf-data" type="application/json">${pdfJson}</script>
  <script type="module">
    (async function () {
      const dataEl = document.getElementById('preauth-pdf-data');
      const root = document.getElementById('pdf-pages-root');
      const statusEl = document.getElementById('pdf-load-status');
      const printBtn = document.getElementById('print-btn');
      if (!dataEl || !root) return;
      let pdfList = [];
      let imageDocCount = 0;
      try {
        const parsed = JSON.parse(dataEl.textContent || '{}');
        pdfList = parsed.pdfs || [];
        imageDocCount = parsed.imageDocCount || 0;
      } catch (e) {
        console.error(e);
      }
      if (pdfList.length === 0) {
        if (statusEl) statusEl.style.display = 'none';
        if (printBtn) printBtn.disabled = false;
        return;
      }
      function base64ToUint8Array(base64) {
        const binary = atob(base64);
        const len = binary.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
        return bytes;
      }
      try {
        const pdfjsLib = await import('https://unpkg.com/pdfjs-dist@4.4.168/build/pdf.mjs');
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://unpkg.com/pdfjs-dist@4.4.168/build/pdf.worker.mjs';
        const scale = 150 / 72;
        let pdfCanvasIndex = 0;
        for (let p = 0; p < pdfList.length; p++) {
          const data = base64ToUint8Array(pdfList[p]);
          const loadingTask = pdfjsLib.getDocument({ data });
          const pdf = await loadingTask.promise;
          for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
            const page = await pdf.getPage(pageNum);
            const viewport = page.getViewport({ scale });
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            canvas.width = viewport.width;
            canvas.height = viewport.height;
            const renderTask = page.render({ canvasContext: ctx, viewport });
            await renderTask.promise;
            const wrap = document.createElement('div');
            wrap.className = 'doc-page';
            pdfCanvasIndex += 1;
            wrap.appendChild(canvas);
            root.appendChild(wrap);
          }
        }
      } catch (err) {
        console.error('PDF render failed', err);
        if (statusEl) {
          statusEl.textContent = 'Some PDFs could not be loaded for preview. Try refreshing.';
          statusEl.style.color = '#b91c1c';
        }
      } finally {
        if (statusEl) statusEl.style.display = 'none';
        if (printBtn) printBtn.disabled = false;
      }
    })();
  </script>
</body>
</html>`
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = getSessionFromRequest(request)
    if (!user) {
      return unauthorizedResponse()
    }

    if (!['INSURANCE', 'INSURANCE_HEAD', 'ADMIN', 'TESTER'].includes(user.role)) {
      return errorResponse('Forbidden: Only Insurance can view pre-auth print', 403)
    }

    const { id: leadId } = await params

    const lead = await prisma.lead.findUnique({
      where: { id: leadId },
      include: {
        kypSubmission: {
          include: {
            preAuthData: { include: { suggestedHospitals: true } },
          },
        },
        admissionRecord: {
          select: {
            admissionDate: true,
            surgeryDate: true,
          },
        },
        insuranceInitiateForm: {
          select: {
            totalAuthorizedAmount: true,
            amountToBePaidByInsurance: true,
            totalBillAmount: true,
          },
        },
      },
    })

    if (!lead || !lead.kypSubmission || !lead.kypSubmission.preAuthData) {
      return errorResponse('Pre-authorization not found', 404)
    }

    const kyp = lead.kypSubmission
    const preAuth = kyp.preAuthData!

    const docUrls: string[] = []
    if (kyp.insuranceCardFileUrl) docUrls.push(kyp.insuranceCardFileUrl)
    if (kyp.aadharFileUrl) docUrls.push(kyp.aadharFileUrl)
    if (kyp.panFileUrl) docUrls.push(kyp.panFileUrl)
    if (kyp.prescriptionFileUrl) docUrls.push(kyp.prescriptionFileUrl)
    pushJsonFileUrls(kyp.aadharFiles, docUrls)
    pushJsonFileUrls(kyp.panFiles, docUrls)
    pushJsonFileUrls(kyp.diseasePhotos, docUrls)
    pushJsonFileUrls(kyp.otherFiles, docUrls)
    pushJsonFileUrls(preAuth.diseaseImages, docUrls)
    pushJsonFileUrls(preAuth.investigationFileUrls, docUrls)
    pushJsonFileUrls(preAuth.prescriptionFiles, docUrls)

    const seen = new Set<string>()
    const uniqueUrls = docUrls.filter((u) => {
      if (!u || seen.has(u)) return false
      seen.add(u)
      return true
    })

    const imageDataUrls: Array<{ data: string; mime: string }> = []
    const pdfBase64List: string[] = []

    for (const url of uniqueUrls) {
      const fetched = await fetchUrlAsBase64(url)
      if (!fetched) continue
      const kind = classifyFetched(url, fetched.mime)
      if (kind === 'pdf') {
        pdfBase64List.push(fetched.data)
      } else if (kind === 'image') {
        imageDataUrls.push({ data: fetched.data, mime: fetched.mime })
      }
    }

    const suggestedHospitals = preAuth.suggestedHospitals ?? []
    // Find the doctor from the matching suggested hospital
    const matchedHospital = preAuth.requestedHospitalName
      ? suggestedHospitals.find(
          (h) => h.hospitalName?.trim() === preAuth.requestedHospitalName?.trim()
        )
      : null
    const doctorName = lead.ipdDrName ?? matchedHospital?.suggestedDoctor ?? null
    const selectedRoomRent = getSelectedHospitalRoomRent(
      suggestedHospitals,
      preAuth.requestedHospitalName,
      preAuth.requestedRoomType
    )
    const roomRentDisplay = (() => {
      if (selectedRoomRent != null) {
        const n = Number(selectedRoomRent)
        if (!Number.isNaN(n) && n === 0) return null
        return `₹${n.toLocaleString('en-IN')}`
      }
      if (preAuth.roomRent == null || preAuth.roomRent === '') return null
      if (Number.isNaN(Number(preAuth.roomRent))) {
        const s = String(preAuth.roomRent).trim()
        return isZeroLike(s) ? null : s
      }
      const n = Number(preAuth.roomRent)
      if (n === 0) return null
      return `₹${n.toLocaleString('en-IN')}`
    })()
    const insuranceDisplay =
      (preAuth.insurance || lead.insuranceName || kyp.insuranceCard || null) ?? null

    const fmtRupee = (n: number | null | undefined) => {
      if (n == null || n <= 0) return null
      return `₹${n.toLocaleString('en-IN')}`
    }

    const tentativeBill =
      matchedHospital?.tentativeBill ??
      suggestedHospitals.find((h) => (h.tentativeBill ?? 0) > 0)?.tentativeBill ??
      null

    const approvedRaw = preAuth.approvedAmount
    const approvedNum =
      approvedRaw != null && approvedRaw !== '' ? Number(String(approvedRaw).replace(/[₹,\s]/g, '')) : 0
    const initialApprovalDisplay =
      fmtRupee(!Number.isNaN(approvedNum) && approvedNum > 0 ? approvedNum : null) ??
      fmtRupee(lead.insuranceInitiateForm?.totalAuthorizedAmount) ??
      fmtRupee(lead.insuranceInitiateForm?.amountToBePaidByInsurance)

    const tentativeCostDisplay =
      fmtRupee(tentativeBill) ??
      fmtRupee(lead.insuranceInitiateForm?.totalBillAmount) ??
      (lead.billAmount && Number(lead.billAmount) > 0 ? fmtRupee(Number(lead.billAmount)) : null)

    const formatDate = (d: Date | null | undefined) => {
      if (!d) return null
      return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    }

    const html = buildPreAuthHtml({
      patientName: lead.patientName || '—',
      initialApproval: initialApprovalDisplay,
      tentativeCost: tentativeCostDisplay,
      admissionDate: formatDate(lead.admissionRecord?.admissionDate) ?? formatDate(lead.ipdAdmissionDate) ?? formatDate(preAuth.expectedAdmissionDate),
      surgeryDate: formatDate(lead.admissionRecord?.surgeryDate) ?? formatDate(preAuth.expectedSurgeryDate),
      preAuth: {
        insurance: insuranceDisplay,
        tpa: preAuth.tpa ?? null,
        sumInsured: preAuth.sumInsured ?? null,
        roomRent: roomRentDisplay,
        capping: preAuth.capping ? String(preAuth.capping) : null,
        copay: preAuth.copay ?? null,
        icu: preAuth.icu ?? null,
        requestedHospitalName: preAuth.requestedHospitalName ?? null,
        requestedRoomType: preAuth.requestedRoomType ?? null,
        diseaseDescription: preAuth.diseaseDescription ?? null,
        doctorName,
      },
      imageDataUrls,
      pdfBase64List,
    })

    return new Response(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
      },
    })
  } catch (error) {
    console.error('Error generating pre-auth print view:', error)
    return errorResponse('Failed to generate pre-auth print view', 500)
  }
}
